---
name: minecraft-build-backend
description: Use when the user wants a self-hosted or local build service for Minecraft mods/plugins — Spring Boot Build API, job queue, status/logs, artifact storage, authentication, isolated environments, Woodpecker CI, Dagger, and Temurin toolchain setup. Treat nothing as live until deployed and verified.
---

# Minecraft Build Backend

## Honesty first
This skill provides **scaffolds, scripts, and architecture guidance**. It does **not** include:
- A full Eclipse Temurin JDK binary
- A running Woodpecker server or agent
- A running Spring Boot application
- Pre-built mod JARs

Never report a job as succeeded or a JAR as available unless a real executor produced and you inspected the artifact.

## Components covered (user’s requested list)

| # | Item | What the plugin provides |
|---|------|---------------------------|
| 1 | Eclipse Temurin Java 21 JDK | Download + verify script → `scaffolds/scripts/download-temurin21.sh` |
| 2 | Fabric 1.21.x Example Mod Template | Generator script + guidance → `create-fabric-template.sh` |
| 3 | NeoForge 1.21.x Mod Template | Generator script + MDK links → `create-neoforge-template.sh` |
| 4 | Fabric Loom + dependencies | Version pinning guidance in java-modder skill + template scripts |
| 5 | NeoForge ModDevGradle | Same |
| 6 | Woodpecker Server deployment | `scaffolds/woodpecker/docker-compose.yml` + `.env.example` |
| 7 | Woodpecker Build Agent | Included in the same compose file |
| 8 | Dagger CLI & Engine | Reference + recommended pipeline patterns (not vendored binary) |
| 9 | Spring Boot Backend application code | Scaffold under `scaffolds/spring-boot-build-service/` |
| 10 | Build API & Job Queue | Controllers + service stubs + queue model |
| 11 | Build Status & Live Log | Status endpoints + log streaming design |
| 12 | JAR Artifact Storage & Download API | Storage service + download endpoint stubs |
| 13 | API Authentication & Permission | Security config + API-key / JWT skeleton |
| 14 | Secure Isolated Build Environment | Docker-based isolation notes; never expose host docker.sock to untrusted builds in production |
| 15 | Build Test & Error Reporting | Result model + error parsing guidance |

## Recommended architecture

```
User / AI  →  Spring Boot Build API  →  Job Queue (DB or Redis)
                    ↓
              Worker / Agent  →  Isolated container (Temurin 21 + project sources)
                    ↓
              Artifact store (filesystem or S3-compatible) + logs
```

Optional outer CI: Woodpecker triggers on git push and can call the Build API or run Gradle directly inside a controlled pipeline.

## Spring Boot scaffold usage
1. Copy `scaffolds/spring-boot-build-service/` to a new repo.
2. Complete TODOs (real persistence, queue implementation, storage backend, secrets).
3. Build and run only after tests pass.
4. Protect all mutating endpoints with authentication.
5. Run builds in disposable containers with CPU/memory/time limits; never mount the host Docker socket into untrusted build containers.

## Woodpecker
- Use the provided `docker-compose.yml` as a starting point.
- Generate a strong `WOODPECKER_AGENT_SECRET`.
- Prefer binding the UI to localhost or behind a reverse proxy with TLS.
- Agent example mounts docker.sock for convenience in a **dedicated** lab machine only. For shared or multi-tenant use, switch to a more isolated runner (e.g. Kubernetes with restricted privileges).

## Dagger
- Treat Dagger as an optional inner build engine that can be invoked from Woodpecker steps or from the Spring Boot worker.
- Do not claim Dagger is installed until `dagger version` succeeds on the target host.

## Verification checklist before saying “ready”
- [ ] `java -version` → 21.x from the intended Temurin install
- [ ] Project template matches requested Minecraft + loader version
- [ ] `./gradlew build` (or CI equivalent) has been run and logs inspected
- [ ] JAR exists, is a valid archive, contains expected metadata
- [ ] If using the Build API: health endpoint OK, auth works, a test job completed and artifact downloaded
- [ ] Woodpecker (if used): server + agent connected, a test pipeline green

## Security
- Never embed real secrets in the plugin or in committed scaffolds.
- Rotate agent secrets and API keys.
- Quarantine untrusted source; resource-limit every build.
- Log enough for debugging; do not log secrets or full customer source in shared logs.
