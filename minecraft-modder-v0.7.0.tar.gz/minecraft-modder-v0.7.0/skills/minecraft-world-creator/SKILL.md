---
name: minecraft-world-creator
description: Use when planning or generating Minecraft Java worlds, realistic maps, terrain, structures, previews, and complete world-folder ZIP packages.
---

# Minecraft World Creator

## Goal
Help create a playable Minecraft Java world from a natural-language description. The intended deliverable, when generation tools are actually available, is a complete Minecraft world folder plus a ZIP containing that folder, and a preview image of the resulting world. This skill does not create 3D model assets; focus on the world and its preview.

## Ask requirements before generation
Gather missing essentials without repeating answered questions: Minecraft edition and exact version; world theme (realistic city, island, village, forest, mountain range, ocean, fantasy, cyberpunk, or custom); dimensions; key features/exclusions; terrain/biome and seed preferences; performance constraints; and output expectations. Explain that very large maps require more time, disk, and memory.

## Generation workflow
1. Convert the prompt into a world specification: boundaries, height range, biome/terrain plan, regions, landmarks, roads/waterways, structure list, palette, and generation order.
2. Choose a real generation method appropriate to the task: a version-compatible datapack/worldgen configuration, server-side world generator plugin, programmatic Anvil-region writer, or established world-editing pipeline. Verify exact-version compatibility. Do not claim a method is available unless its executable/runtime is connected.
3. Generate in bounded regions/chunks with deterministic seeds and resumable region checkpoints where possible. Avoid loading a huge world entirely into memory.
4. Validate world metadata and region files; check that the world opens in the target Minecraft version. If a Minecraft runtime exists, load it and inspect representative regions.
5. Capture a preview from the actual generated world using an in-game screenshot or real renderer. If only an AI concept image is available, label it as concept art, not an in-game screenshot or proof of a finished world.
6. Package the complete world directory (including `level.dat`, region data, and required dimension/data folders) into a ZIP while preserving directory structure.
7. Inspect the ZIP, verify required files and nonzero region data, and report exact filename and size. Never call a plan, schematic, empty folder, or screenshot a complete world ZIP.

## Large-world limits
Explain expected storage, memory, generation time, and chunk counts before very large jobs. Prefer region/chunk batching and checkpoints. Do not promise a fixed completion time without measurement. Offer a smaller test region if compatibility/performance is uncertain. Do not silently reduce requested dimensions.

## Preview and truthfulness
Distinguish among design plan, concept art, generated world data, world opened in Minecraft, and screenshot captured from that running world. Never invent a screenshot or imply an image proves the world is playable.

## Deliverables and limitations
When generation infrastructure exists, provide the complete world folder, its ZIP, preview image(s) captured from the generated world, and a README with target version, seed, generation method, dimensions, and limitations. If no world-generation executor or filesystem is available, provide only the specification and generation source/instructions and explicitly state that the playable world and ZIP have not been generated. Do not claim this plugin contains a running world-generation engine unless deployed and verified.
