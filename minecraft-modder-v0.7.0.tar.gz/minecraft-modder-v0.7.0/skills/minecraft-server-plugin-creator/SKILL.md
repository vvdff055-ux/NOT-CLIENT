---
name: minecraft-server-plugin-creator
description: Use when creating, debugging, testing, packaging, or documenting Minecraft Java server plugins for Paper, Spigot, Bukkit, Velocity, or BungeeCord.
---

# Minecraft Server Plugin Creator

## Scope
Create Java server-plugin projects for Minecraft 1.21.x. First ask for the target platform and exact server/Minecraft version if missing. Do not assume every platform shares one API or one JAR.

## Platform separation
- Paper, Spigot, and Bukkit use related Bukkit APIs, but supported API versions and implementation-specific features differ. Choose a declared API target and verify compatibility against official documentation.
- Velocity and BungeeCord are proxy platforms with distinct APIs, lifecycle hooks, metadata, and dependencies. They require separate project configurations and artifacts from Bukkit-family plugins.
- Never label a Paper-only API implementation as universally compatible with Spigot/Bukkit without checking every API call.
- Do not package one universal JAR for all five platforms unless a tested multi-platform architecture explicitly supports it.

## Requirements gathering
Ask only for missing essentials: target platform(s), exact Minecraft/server version, plugin name/id, requested commands/events/features, configuration needs, permissions, and storage/database requirements. For a request covering all platforms, explain which features can be shared in common Java code and which need platform adapters.

## Project generation
For each platform-specific module include Gradle or Maven build files with pinned, verified dependencies; Java source and package structure; correct platform metadata (for example `plugin.yml`/Paper metadata or proxy-specific metadata); command, event/listener, permission, configuration, and localization resources as requested; README with platform/version support matrix and build instructions; and tests for reusable logic and metadata/configuration validation.

Use Java 21 only when supported/required by the exact target server toolchain. Check official release documentation for the exact Minecraft 1.21.x patch and API version before selecting dependency coordinates. Mark unverified coordinates rather than inventing them.

## Build, tests, and JAR verification
A source project is not a built plugin. Report a successful build only after an actual build executor returns a successful exit code and logs. Inspect the resulting JAR as an archive and verify expected metadata, classes, and resources. Test against the declared server/proxy version where an actual test environment exists. Otherwise state that runtime compatibility remains untested.

## Security and output
Treat uploaded projects and build scripts as untrusted. Keep credentials out of source and logs; validate command arguments and permissions; use least privilege; and use ephemeral isolated runners with resource/time/network limits and secret redaction. Never claim a live automatic build service exists unless deployed, callable, and tested. Provide complete source and a platform/version matrix. If no build executor is available, label output source-only and give exact local build commands. Keep a portable checkpoint of platform, version, dependencies, files, completed tasks, blockers, and verified build state.
