---
name: minecraft-java-modder
description: Use when the user wants to design, implement, debug, package, or prepare a Minecraft Java Edition mod project, especially for Fabric or NeoForge. Covers 1.21.x defaults, Loom / ModDevGradle, Gradle Wrapper, Termux limits, build diagnostics, JAR verification, checkpoints, release prep, and integration with the build-backend skill.
---

# Minecraft Java Modder

## Purpose and honesty
Create complete Minecraft Java mod **source** projects. Default to Minecraft Java Edition **1.21.x** (prefer a concrete patch the user names; otherwise 1.21.1 or the latest stable 1.21 line the user confirms) and **Java 21** (Eclipse Temurin recommended).

**This plugin is not a compiler or hosted CI.** Never claim a JAR has been compiled, tested, or is playable unless an actual Java/Gradle build was executed and its output inspected. A ZIP of sources, Gradle files, CI YAML, or a backend scaffold is not a compiled JAR.

## Toolchain

### Java 21 (Temurin)
- Prefer Eclipse Temurin 21 LTS from https://adoptium.net/
- Use `scaffolds/scripts/download-temurin21.sh` to fetch and verify a platform-specific archive.
- After download, set `JAVA_HOME` and confirm `java -version` reports 21.x.
- Do not claim Java is installed until the binary is present and `java -version` succeeds.

### Fabric (Loom)
- For Minecraft **1.21.11 and older** (obfuscated): use plugin id `net.fabricmc.fabric-loom-remap` (or legacy `fabric-loom`).
- For Minecraft **26.1+** (unobfuscated): use `net.fabricmc.fabric-loom`.
- Always pin a concrete Loom version compatible with the target Minecraft version. Check https://docs.fabricmc.net/develop/loom/ and Maven Central.
- Generate projects via `scaffolds/scripts/create-fabric-template.sh` or official Fabric example mod adjusted to the target version. Do not use a 26.x template for a 1.21.x project without explicit conversion.

### NeoForge (ModDevGradle)
- Prefer `net.neoforged.moddev` (ModDevGradle). Check latest version at https://projects.neoforged.net/neoforged/ModDevGradle
- Official MDKs: https://github.com/orgs/NeoForgeMDKs/repositories (e.g. MDK-1.21.1-ModDevGradle).
- Use `scaffolds/scripts/create-neoforge-template.sh` or clone the matching MDK and replace placeholders.

### Gradle
- Always commit / generate the **Gradle Wrapper** (`gradlew` / `gradlew.bat`) for the project.
- Prefer the Wrapper over a system Gradle install for reproducibility.
- Do not vendor the full Gradle source tree into the plugin or user project.

## Project creation workflow
1. Confirm Minecraft version, loader (Fabric / NeoForge), mod id, package, Java version.
2. Generate or clone a matching template; never silently use a wrong-version example.
3. Set `mod_version`, `maven_group`, `archives_base_name`, dependencies (Fabric API / NeoForge version).
4. Implement features; keep checkpoints (see below).
5. Build only when a real executor is available: `./gradlew build` (or CI).
6. Verify the JAR: exists under `build/libs/`, opens as ZIP, contains loader metadata and expected classes.
7. Package release only after verification.

## Termux / Android
- Not a guaranteed or officially supported Fabric/NeoForge build host.
- JDK availability, native deps, memory, and architecture often block builds.
- Provide scripts for review; mark steps as verified / unverified / unsupported. Never claim an Android build succeeded from generated scripts alone.

## Build logs and strict artifact verification
- Diagnose only real logs or executor output.
- Identify first actionable error (task, file, line when possible).
- Report “built” only after status + logs + JAR inspection.
- Without execution: say “not built/verified.”

## Portable checkpoints
Maintain a plain-text/Markdown checkpoint: mod id/features, MC + loader + Java versions, files changed, decisions, pending work, last verified artifact state. User can paste it into a later chat.

## Monetization / release
Help with README, licensing notes, changelog, packaging. Do not promise sales or revenue. Separate facts, estimates, and recommendations.

## Integration with build backend
When the user wants remote or queued builds, hand off to the `minecraft-build-backend` skill. The backend scaffold is under `scaffolds/spring-boot-build-service/` and is **not** a running service until the user deploys and verifies it.
