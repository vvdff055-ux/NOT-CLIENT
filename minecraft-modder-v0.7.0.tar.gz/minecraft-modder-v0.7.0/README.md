# Minecraft Creator Studio AI — v0.7.0

Private Minecraft creation assistant covering:

- **Java mods:** Fabric and NeoForge (1.21.x default), version-aware planning, Gradle Wrapper, Loom / ModDevGradle, Termux limits, build diagnostics, JAR inspection, checkpoints, release prep.
- **Server plugins:** Paper, Spigot, Bukkit, Velocity, BungeeCord — platform-specific projects only.
- **Custom worlds:** prompt-driven planning, generation workflows, validation, preview rules, world-folder ZIP packaging.
- **Build backend scaffold (new in 0.7.0):** Spring Boot Build API, job queue, status + live logs, JAR artifact storage/download, API auth, isolated build environment guidance, Woodpecker CI + agent Docker Compose, Dagger references, Temurin 21 download scripts, Fabric/NeoForge template generators.

## What this plugin ships

| Item | Status in plugin |
|------|------------------|
| Skill instructions & honesty rules | Full |
| Spring Boot Build Service **scaffold** (API, queue, auth, storage models) | Yes — source under `scaffolds/spring-boot-build-service/` |
| Woodpecker Server + Agent **docker-compose** | Yes — `scaffolds/woodpecker/` |
| Temurin 21 **download & verify script** | Yes — `scaffolds/scripts/download-temurin21.sh` |
| Fabric / NeoForge **template generator scripts** | Yes — `scaffolds/scripts/` |
| Full Eclipse Temurin JDK binary ZIP | **No** (too large; use official Adoptium) |
| Pre-running Woodpecker / Dagger / Spring Boot server | **No** |
| Pre-built mod JARs | **No** |

## Honesty rules (unchanged & strengthened)

- Never claim a JAR, world folder, ZIP, or in-game screenshot exists unless the operation actually ran and the resulting files were inspected.
- A generated source tree, Gradle config, CI YAML, or concept image is **not** a completed build or world.
- Treat any “supplied archive” as reference only until verified and installed.
- Untrusted builds must run in isolated environments with resource/time limits. Do not expose host Docker sockets or secrets to arbitrary code.

## World Creator behavior

Gather requirements first (edition/version, type, dimensions, seed, terrain/biomes, structures, style, limits, output). Produce a complete world folder + ZIP only after real generation and validation. Label AI concept art as concept art, never as an in-game screenshot.

## Quick start for the new build backend pieces

```bash
# 1. Get a real JDK 21
bash scaffolds/scripts/download-temurin21.sh

# 2. Generate a Fabric 1.21.x template (script prints steps / can clone official example)
bash scaffolds/scripts/create-fabric-template.sh my-mod

# 3. Optional: start Woodpecker (requires Docker + secrets)
cp scaffolds/woodpecker/.env.example scaffolds/woodpecker/.env
# edit .env then:
docker compose -f scaffolds/woodpecker/docker-compose.yml up -d

# 4. Spring Boot scaffold is under scaffolds/spring-boot-build-service/
#    Complete the TODOs, add real queue (Redis/DB), storage, and auth before production use.
```

## Version history

- **0.7.0** — Build-backend scaffolds, Temurin download script, template generators, Woodpecker compose, expanded skills, stricter honesty.
- **0.6.0** — Previous release (mods + plugins + worlds guidance only).
