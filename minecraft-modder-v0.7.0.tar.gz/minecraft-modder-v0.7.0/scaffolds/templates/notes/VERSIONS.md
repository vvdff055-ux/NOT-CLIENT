# Version notes (as of plugin 0.7.0 packaging)

Always re-check official sources before pinning.

## Java
- Target: **Eclipse Temurin 21** (LTS)
- Download: https://adoptium.net/ or API used by `download-temurin21.sh`

## Fabric
- Minecraft **1.21.x** is still obfuscated → prefer `net.fabricmc.fabric-loom-remap` / documented Loom for that line
- Minecraft **26.1+** is unobfuscated → `net.fabricmc.fabric-loom`
- Loom releases: https://github.com/FabricMC/fabric-loom/releases
- Docs: https://docs.fabricmc.net/develop/loom/

## NeoForge
- ModDevGradle: https://projects.neoforged.net/neoforged/ModDevGradle
- MDKs: https://github.com/orgs/NeoForgeMDKs/repositories
  - e.g. `MDK-1.21.1-ModDevGradle`

## Woodpecker
- Images: `woodpeckerci/woodpecker-server:v3`, `woodpeckerci/woodpecker-agent:v3`
- Docs: https://woodpecker-ci.org/docs/administration/installation/docker-compose

## Dagger
- Install from official docs; do not claim present until `dagger version` works on the host.
