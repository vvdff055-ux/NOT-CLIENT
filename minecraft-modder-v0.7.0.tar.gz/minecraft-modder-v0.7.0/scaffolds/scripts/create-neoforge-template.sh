#!/usr/bin/env bash
# Helper for NeoForge 1.21.x via official MDK (ModDevGradle)
set -euo pipefail

MOD_NAME="${1:-examplemod}"
MC_LINE="${MC_LINE:-1.21.1}"

echo "=== NeoForge template helper ==="
echo "Target mod name : $MOD_NAME"
echo "Minecraft line  : $MC_LINE"
echo ""
echo "Official MDKs live under https://github.com/orgs/NeoForgeMDKs/repositories"
echo "Examples:"
echo "  - MDK-1.21.1-ModDevGradle"
echo "  - MDK-1.21-ModDevGradle"
echo ""
echo "Quick start:"
echo "  git clone https://github.com/NeoForgeMDKs/MDK-${MC_LINE}-ModDevGradle.git $MOD_NAME"
echo "  cd $MOD_NAME"
echo "  # edit gradle.properties / build.gradle for mod id, group, version"
echo "  # set JAVA_HOME to Temurin 21"
echo "  ./gradlew build"
echo ""
echo "ModDevGradle plugin: net.neoforged.moddev (check latest on projects.neoforged.net)"
echo "After build, inspect build/libs for the mod JAR and neoforge.mods.toml."
