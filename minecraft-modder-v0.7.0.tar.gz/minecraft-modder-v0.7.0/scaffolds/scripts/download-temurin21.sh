#!/usr/bin/env bash
# Download and verify Eclipse Temurin JDK 21 from Adoptium.
# This script does NOT ship the JDK; it fetches the official binary.
set -euo pipefail

VERSION="21"
# Adjust OS/ARCH as needed. Common values:
#   linux x64 / aarch64
#   windows x64
#   mac aarch64 / x64
OS="${OS:-linux}"
ARCH="${ARCH:-x64}"
IMAGE_TYPE="jdk"
OUT_DIR="${OUT_DIR:-$HOME/jdks}"
mkdir -p "$OUT_DIR"

API="https://api.adoptium.net/v3/binary/latest/${VERSION}/ga/${OS}/${ARCH}/${IMAGE_TYPE}/hotspot/normal/eclipse"
TMP="$(mktemp -d)"
ARCHIVE="$TMP/temurin21.tar.gz"

echo "Fetching Temurin ${VERSION} (${OS}/${ARCH}) ..."
curl -fsSL -o "$ARCHIVE" "$API"

# Basic sanity: file must be non-trivial size
SIZE=$(wc -c < "$ARCHIVE" | tr -d ' ')
if [ "$SIZE" -lt 1000000 ]; then
  echo "ERROR: downloaded file is too small (${SIZE} bytes). Not a full JDK."
  exit 1
fi

echo "Extracting to $OUT_DIR ..."
tar -xzf "$ARCHIVE" -C "$OUT_DIR"
EXTRACTED=$(find "$OUT_DIR" -maxdepth 1 -type d -name "jdk-21*" | sort | tail -1)

if [ -z "$EXTRACTED" ]; then
  echo "ERROR: could not find extracted jdk-21 directory"
  exit 1
fi

echo "Installed under: $EXTRACTED"
echo "Add to your shell:"
echo "  export JAVA_HOME=\"$EXTRACTED\""
echo "  export PATH=\"\$JAVA_HOME/bin:\$PATH\""
echo "Then verify:"
echo "  java -version"
