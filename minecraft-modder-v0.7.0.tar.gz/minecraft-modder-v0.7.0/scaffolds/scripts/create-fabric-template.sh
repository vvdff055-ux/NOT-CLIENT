#!/usr/bin/env bash
# Helper to start a Fabric mod for Minecraft 1.21.x
# Does not embed a full template; clones or points to official sources.
set -euo pipefail

MOD_NAME="${1:-example-mod}"
MC_VERSION="${MC_VERSION:-1.21.1}"
# Official example is version-specific; prefer generating via Fabric docs or a known-good 1.21.x repo.
# For a quick start, many users clone:
#   https://github.com/FabricMC/fabric-example-mod
# then change gradle.properties to the desired Minecraft / Loom / Loader / API versions.

echo "=== Fabric template helper ==="
echo "Target mod name : $MOD_NAME"
echo "Minecraft       : $MC_VERSION"
echo ""
echo "Recommended steps:"
echo "1. Clone a verified 1.21.x example (or use Fabric's generator if available):"
echo "   git clone https://github.com/FabricMC/fabric-example-mod.git $MOD_NAME"
echo "   cd $MOD_NAME"
echo ""
echo "2. Edit gradle.properties:"
echo "   minecraft_version=$MC_VERSION"
echo "   # pin loader, fabric_api, and loom versions compatible with $MC_VERSION"
echo "   # For 1.21.x (obfuscated) use fabric-loom-remap / fabric-loom as documented"
echo ""
echo "3. Ensure Gradle Wrapper is present (./gradlew)."
echo "4. Set JAVA_HOME to Temurin 21."
echo "5. Run: ./gradlew genSources build"
echo ""
echo "Do NOT use a Minecraft 26.x template for a 1.21.x project without explicit migration."
echo "After first successful build, verify build/libs/*.jar contains fabric.mod.json and your classes."
