# MC Studio Build Service (scaffold)

Spring Boot 3 + Java 21 skeleton for:

- Build job API (`POST /api/v1/builds`)
- Status + list
- Log endpoint
- Artifact download
- API-key authentication (header `X-API-Key`)

## Not production-ready until you

1. Replace H2 with a real database
2. Implement a real job queue / worker
3. Run Gradle builds inside **isolated containers** with Temurin 21
4. Store artifacts on durable storage
5. Change `mcstudio.api-key` and disable the default
6. Add rate limits, audit logs, and resource quotas

## Run (after completing TODOs)

```bash
export JAVA_HOME=... # Temurin 21
./mvnw spring-boot:run
# or: mvn spring-boot:run
```

Auth: send header `X-API-Key: <your-key>`.

The default `BuildJobService.runAsync` **does not** compile mods; it only demonstrates the API shape. Wire a real executor before reporting successful builds.
